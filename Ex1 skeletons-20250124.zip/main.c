#include "cipher.h"
#include "tests.h"


// your code goes here

int main (int argc, char *argv[])
{
  // your code goes here
}
