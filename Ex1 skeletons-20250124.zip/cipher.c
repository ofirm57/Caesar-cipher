#include "cipher.h"

/// IN THIS FILE, IMPLEMENT EVERY FUNCTION THAT'S DECLARED IN cipher.h.


// See full documentation in header file
void encode (char s[], int k)
{
  // your code goes here
}

// See full documentation in header file
void decode (char s[], int k)
{
  // your code goes here
}
